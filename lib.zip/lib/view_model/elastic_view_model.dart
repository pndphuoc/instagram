import 'package:instagram/services/elastic_services.dart';

class ElasticViewModel {
  final ElasticService _elasticService = ElasticService();
  List<Map<String, dynamic>> _searchResults = [];

  List<Map<String, dynamic>> get searchResults => _searchResults;

  Future<void> searchData(String index, Map<String, dynamic> query) async {
    final res = await _elasticService.searchData(index, query);
    _searchResults.addAll(res);
  }

  Future<void> addDataToIndex(String index, Map<String, dynamic> data) async {
    await _elasticService.addDataToIndex(index, data);

  }
}