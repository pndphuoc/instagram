import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:instagram/services/authentication_services.dart';

class AuthenticationViewModel extends ChangeNotifier{
  final AuthenticationService _service = AuthenticationService();

  Future<String> login({required String email, required String password}) async {
    return await _service.login(email: email, password: password);
  }

  Future<void> logout() async {
    await _service.logout();
  }

  Future<bool> signInWithGoogle() async {
    return await _service.signInWithGoogle();
  }

  Future<String> signUp({required String email, required String password, required String username, required String bio, Uint8List? file}) async {
    return await _service.signUp(email: email, password: password, username: username, bio: bio, file: file);
  }

  Future<String> completeSignInWithGoogle({required String username, String bio = "", Uint8List? file}) async {
    return await _service.completeSignInWithGoogle(username: username, bio: bio, file: file);
  }

  Future<bool> isNewUser() async {
    return await _service.isNewUser();
  }
}