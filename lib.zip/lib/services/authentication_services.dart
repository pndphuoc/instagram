import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:instagram/interface/authenticatin_interface.dart';

import '../resources/storage_methods.dart';
import '../models/user.dart' as model;

class AuthenticationService implements IAuthenticationService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  @override
  Future<String> completeSignInWithGoogle(
      {required String username, String bio = "", Uint8List? file}) async {
    String res = "Some error occurred";

    try {
      String? photoUrl;
      if (file != null) {
        photoUrl = await StorageMethods()
            .uploadPhotoToStorage('profilePics', file, false);
      }

      final currentUser = FirebaseAuth.instance.currentUser;

      model.User user = model.User(
          username: username,
          uid: currentUser!.uid,
          email: currentUser.email!,
          bio: bio,
          followers: [],
          followings: [],
          postIds: [],
          photoUrl: photoUrl ?? "",
          followersCount: 0,
          followingsCount: 0,
          postsCount: 0);

      _firestore.collection('users').doc(currentUser.uid).set(user.toJson());
      res = 'success';
    } catch (err) {
      print(err.toString());
    }
    return res;
  }

  @override
  Future<String> login(
      {required String email, required String password}) async {
    String res = "Some error occurred";

    try {
      if (email.isNotEmpty && password.isNotEmpty) {
        await _auth.signInWithEmailAndPassword(
            email: email, password: password);
        res = "Login successful";
      } else {
        res = "Please enter all fields";
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'wrong-password') {
        res = "Wrong password";
      } else if (e.code == 'user-not-found') {
        res = "User not found";
      }
    } catch (err) {
      print(err.toString());
    }

    return res;
  }

  @override
  Future<void> logout() async {
    if (await _googleSignIn.isSignedIn()) {
      await _googleSignIn.disconnect();
      await _googleSignIn.signOut();
    }
    await FirebaseAuth.instance.signOut();
  }

  @override
  Future<bool> signInWithGoogle() async {
    // Trigger the authentication flow
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

    // Obtain the auth details from the request
    final GoogleSignInAuthentication? googleAuth =
        await googleUser?.authentication;

    // Create a new credential
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth?.accessToken,
      idToken: googleAuth?.idToken,
    );

    final authResult =
        await FirebaseAuth.instance.signInWithCredential(credential);
    if (authResult.additionalUserInfo!.isNewUser) {
      return true;
    }

    return false;
  }

  @override
  Future<String> signUp(
      {required String email,
      required String password,
      required String username,
      required String bio,
      Uint8List? file}) async {
    String res = "Some error occurred";
    try {
      if (email.isNotEmpty ||
          password.isNotEmpty ||
          username.isNotEmpty ||
          bio.isNotEmpty) {
        UserCredential cred = await _auth.createUserWithEmailAndPassword(
            email: email, password: password);

        String? photoUrl;
        if (file != null) {
          photoUrl = await StorageMethods()
              .uploadPhotoToStorage('profilePics', file, false);
        }

        model.User user = model.User(
            username: username,
            uid: cred.user!.uid,
            email: email,
            bio: bio,
            followers: [],
            followings: [],
            photoUrl: photoUrl ?? "",
            followingsCount: 0,
            followersCount: 0,
            postIds: [],
            postsCount: 0);

        _firestore.collection('users').doc(cred.user!.uid).set(user.toJson());
        res = "success";
      }
    } catch (err) {
      res = err.toString();
    }
    return res;
  }

  @override
  Future<bool> isNewUser() async {
    try {
      List<String> signInMethods =
          await _auth.fetchSignInMethodsForEmail(_auth.currentUser!.email!);
      if (signInMethods.isEmpty) {
        print('Email has never been logged in before.');
        return true;
      } else {
        print('Email has been logged in using these methods:');
        return false;
      }
    } catch (e) {
      print('Error occurred while fetching sign-in methods: $e');
      rethrow;
    }
  }
}
