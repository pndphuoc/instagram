import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:instagram/interface/post_interface.dart';

import '../models/post.dart';

class PostService implements IPostServices {
  final FirebaseStorage _firebaseStorage = FirebaseStorage.instance;
  final CollectionReference _postsCollection = FirebaseFirestore.instance.collection('posts');

  @override
  Future<List<Post>> getPosts() async {
    QuerySnapshot snapshot = await _postsCollection.get();
    return snapshot.docs.map((doc) => Post.fromSnap(doc)).toList();
  }

  @override
  Future<String> addPost(Post post) async {
    User currentUser = FirebaseAuth.instance.currentUser!;
    DocumentReference docRef = _postsCollection.doc();
    String uid = docRef.id;
    docRef.set({
      'caption': post.caption,
      'uid': uid,
      'username': post.username,
      'likesCount': post.likesCount,
      'commentsCount': post.commentsCount,
      'timestamp': post.timestamp,
      'postUrl': "post.postUrl",
      'profileImage': post.profileImage,
      'imageUrls': post.imageUrls,
      'likedBy': [],
    });
    return uid;
  }



  @override
  Future<void> updatePost(Post post) async {
    await _postsCollection.doc(post.postId).update({
      'likesCount': post.likesCount,
      'commentsCount': post.commentsCount,
      'imageUrls': post.imageUrls,
    });
  }

  @override
  Future<void> deletePost(String postId) async {
    await _postsCollection.doc(postId).delete();
  }

  @override
  Future<void> likePost(String postId, String userId) async {
    await _postsCollection.doc(postId).update({
      'likesCount': FieldValue.increment(1),
      'likedBy': FieldValue.arrayUnion([userId]),
    });
  }

  @override
  Future<void> unlikePost(String postId, String userId) async {
    await _postsCollection.doc(postId).update({
      'likesCount': FieldValue.increment(-1),
      'likedBy': FieldValue.arrayRemove([userId]),
    });
  }

  @override
  Future<Post> getPost(String postId) async {
    DocumentSnapshot snapshot = await _postsCollection.doc(postId).get();
    if (snapshot.exists) {
      Post post = Post.fromSnap(snapshot);
      return post;
    } else {
      throw Exception('Post not found');
    }
  }
}
