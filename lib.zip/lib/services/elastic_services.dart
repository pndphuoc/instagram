import 'dart:convert';

import 'package:instagram/interface/elastic_interface.dart';
import 'package:elastic_client/src/http_transport.dart';
import 'package:elastic_client/elastic_client.dart' as elastic;
import 'package:http/http.dart' as http;

class ElasticService implements IElasticService {
  String endPoint = "https://huet.es.asia-southeast1.gcp.elastic-cloud.com";
  String privateKey = "private-qe78yhgti3u2kde8ms5t7jjh";
  String publicSearchKey = "search-9mhw8iqaq4t4yc9qs2igvwob";
  String cloudId =
      "HueT:YXNpYS1zb3V0aGVhc3QxLmdjcC5lbGFzdGljLWNsb3VkLmNvbTo0NDMkMzNlN2E5NGJiYjQxNDBkZDllMjMzMWE0YjdmMTYyNjYkYjUwN2JjNzRmYzk1NGY0MDg2YmViMDBhZTI4OGVmMGE=";
  String username = "elastic";
  String password = "yZwwmdW7XnrwRAYk2AwvGOog";

  @override
  Future<void> addDataToIndex(String index, Map<String, dynamic> data) async {
    final response = await http.post(
      Uri.https(cloudId, '$privateKey:@$endPoint/$index/_doc'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(data),
    );

    if (response.statusCode != 201) {
      throw Exception('Failed to add data to index');
    }
  }

  @override
  Future<List<Map<String, dynamic>>> searchData(
      String index, Map<String, dynamic> query) async {
    final bytes = utf8.encode('$username:$password');
    final base64Str = base64.encode(bytes);
    final response = await http.post(
      Uri.parse(
          'https://huet.es.asia-southeast1.gcp.elastic-cloud.com/_search'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Basic $base64Str'
      },
      body: jsonEncode({
        'query': {'match': query}
      }),
    );
    final json = jsonDecode(response.body);
    final hits = json['hits']['hits'];
    print(hits);
    final results = hits.map((hit) => hit['_source'] as Map<String, dynamic>).toList();
    print(results);
    return results;
  }
}
