import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:expandable_text/expandable_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:instagram/ultis/colors.dart';
import 'package:shimmer/shimmer.dart';

import '../models/post.dart';

class PostCard extends StatefulWidget {
  final Post post;

  const PostCard({Key? key, required this.post}) : super(key: key);

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  final double avatarHeight = 20;
  final double avatarWidth = 20;
  late double imageWidth;

  String getElapsedTime(DateTime startTime) {
    Duration timePassed = DateTime.now().difference(startTime);
    if (timePassed.inDays > 30) {
      return '${timePassed.inDays}';
    } else if(timePassed.inDays > 0) {
      return '${timePassed.inDays} days ago';
    } else if (timePassed.inHours > 0) {
      return '${timePassed.inHours} hours ago';
    } else if (timePassed.inMinutes > 0) {
      return '${timePassed.inMinutes} minutes ago';
    } else {
      return '${timePassed.inSeconds} seconds ago';
    }
  }

  @override
  Widget build(BuildContext context) {
    imageWidth = MediaQuery.of(context).size.width - 20;
    return Container(
      margin: const EdgeInsets.only(left: 10, right: 10),
      padding: const EdgeInsets.only(top: 10, bottom: 20),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: postCardBackgroundColor),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const SizedBox(
                width: 10,
              ),
              CircleAvatar(
                radius: avatarHeight,
                backgroundImage: CachedNetworkImageProvider(
                  widget.post.profileImage ?? "",
                ),
              ),
              const SizedBox(
                width: 15,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.post.username,
                      style: Theme.of(context).textTheme.titleSmall,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      getElapsedTime(widget.post.timestamp),
                      style: Theme.of(context).textTheme.bodySmall,
                    )
                  ],
                ),
              ),
              IconButton(
                onPressed: () {},
                padding: EdgeInsets.zero,
                icon: const Icon(Icons.more_horiz),
              ),
              const SizedBox(
                width: 10,
              ),
            ],
          ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.only(left: 15, right: 15),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(25),
              child: CarouselSlider(
                options: CarouselOptions(
                    aspectRatio: 1,
                    reverse: false,
                    scrollPhysics: const BouncingScrollPhysics(),
                    enableInfiniteScroll: false,
                    viewportFraction: 1,
                    onPageChanged: (index, reason) async {
                      //loadVideo(widget.samplePost.medias[index]);
/*                      setState(() {
                        currentPos = index;
                      });*/
                    }),
                items: widget.post.imageUrls.map((e) {
                  return CachedNetworkImage(
                    imageUrl: e,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    fadeInDuration: const Duration(milliseconds: 100),
                    placeholder: (_, __) => Shimmer.fromColors(
                      baseColor: const Color.fromARGB(255, 39, 39, 39),
                      highlightColor: const Color.fromARGB(255, 86, 86, 86),
                      child: const SizedBox(
                        width: double.infinity,
                        height: double.infinity,
                      ),
                    )
                  );
                }).toList(),
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              const SizedBox(
                width: 20,
              ),
              SvgPicture.asset(
                "assets/ic_heart.svg",
                height: 28,
                width: 28,
              ),
              const SizedBox(
                width: 10,
              ),
              Text(
                widget.post.likesCount.toString(),
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(
                width: 10,
              ),
              SvgPicture.asset(
                "assets/ic_comment.svg",
                height: 28,
                width: 28,
              ),
              const SizedBox(
                width: 10,
              ),
              Text(
                widget.post.commentsCount.toString(),
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(
                width: 10,
              ),
              SvgPicture.asset(
                "assets/ic_share.svg",
                height: 28,
                width: 28,
              ),
              const Expanded(child: SizedBox()),
              SvgPicture.asset(
                "assets/ic_bookmark.svg",
                height: 28,
                width: 28,
              ),
              const SizedBox(
                width: 20,
              ),
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15, right: 15),
            child: ExpandableText(
              widget.post.caption,
              expandText: 'show more',
              collapseText: 'show less',
              maxLines: 3,
              animation: true,
              collapseOnTextTap: true,
              expandOnTextTap: true,
              linkColor: Colors.grey,
              linkStyle: GoogleFonts.readexPro(fontWeight: FontWeight.w200),
              animationDuration: const Duration(milliseconds: 500),
              style: GoogleFonts.readexPro(color: Colors.white),
            ),
          ),
          const SizedBox(
            height: 15,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15, right: 15),
            child: GestureDetector(
              onTap: () {},
              child: Text("See all comments",
                  style: Theme.of(context).textTheme.labelLarge),
            ),
          )
        ],
      ),
    );
  }
}
