import 'package:flutter/material.dart';

import '../screens/add_caption_screen.dart';
import '../screens/add_post_screen.dart';
import '../screens/news_feed_screen.dart';
import '../screens/personal_information_screen.dart';

class HomeScreenProvider with ChangeNotifier {
  final List<Widget> screens = [
    const NewsFeedScreen(),
    const Text("Search"),
    const AddPostScreen(),
    const Center(child: Text("notifications", style: TextStyle(color: Colors.white),)),
    const PersonalInformationScreen()
  ];
  final PageController pageController = PageController();

  int _currentIndex = 0;

  int get currentIndex => _currentIndex;

  set currentIndex(int value) {
    _currentIndex = value;
    notifyListeners();
  }

}
