import 'package:instagram/models/post.dart';

class User {
  final String email;
  final String uid;
  final String? photoUrl;
  final String username;
  final String? bio;
  final List followers;
  final List followings;
  final int followersCount;
  final int followingsCount;
  final int postsCount;
  final List postIds;

  User({
    required this.photoUrl,
    required this.uid,
    required this.followers,
    required this.followings,
    required this.postsCount,
    required this.postIds,
    required this.bio,
    required this.followersCount,
    required this.email,
    required this.username,
    required this.followingsCount,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      photoUrl: json['photoUrl'],
      uid: json['uid'],
      followers: json['followers'],
      followings: json['followings'],
      postsCount: json['postsCount'],
      postIds: json['postIds'],
      bio: json['bio'],
      followersCount: json['followersCount'],
      email: json['email'],
      username: json['username'],
      followingsCount: json['followingsCount'],
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['email'] = email;
    data['uid'] = uid;
    data['photoUrl'] = photoUrl;
    data['username'] = username;
    data['bio'] = bio;
    data['followers'] = followers;
    data['followings'] = followings;
    data['followersCount'] = followersCount;
    data['followingsCount'] = followingsCount;
    data['postsCount'] = postsCount;
    data['postIds'] = postIds;
    return data;
  }


}
