import 'package:cloud_firestore/cloud_firestore.dart';

class Post {
  final String caption;
  final String uid;
  final String username;
  final int likesCount;
  final int commentsCount;
  final String? postId;
  final DateTime timestamp;
  final String? postUrl;
  final String? profileImage;
  List<String> imageUrls = [];
  Post({
    required this.caption,
    required this.uid,
    required this.username,
    required this.likesCount,
    required this.commentsCount,
    this.postId,
    required this.timestamp,
    this.postUrl,
    this.profileImage,
    required this.imageUrls,
  });

  factory Post.fromSnap(DocumentSnapshot snapshot) {
    final data = snapshot.data() as Map<String, dynamic>;
    final imageUrlsList = data['imageUrls'] as List<dynamic>;
    final List<String> imageUrls =
    List<String>.from(imageUrlsList.map((imageUrl) => imageUrl as String));
    return Post(
      caption: data['caption'],
      uid: data['uid'],
      username: data['username'],
      likesCount: data['likesCount'],
      commentsCount: data['commentsCount'],
      timestamp: data['timestamp'].toDate(),
      profileImage: data['profileImage'],
      imageUrls: imageUrls,
    );
  }
}
