import 'dart:io';

abstract class IStorageService {
  Future<String> uploadFile(File file, String path);
  Future<void> deleteFile(String url);
}
