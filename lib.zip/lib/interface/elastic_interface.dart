abstract class IElasticService {
  Future<void> addDataToIndex(String index, Map<String, dynamic> data);
  Future<List<Map<String, dynamic>>> searchData(String index, Map<String, dynamic> query);
}