import '../models/post.dart';
import '../models/user.dart';

abstract class IUserService {
  Future<User?> getCurrentUserDetails();

  Future<bool> updatePostInformation(String postId);

}