class RouteName {
  static const String login = "/login";
  static const String signup = "/signup";
  static const String completeRegistration = "/completeRegistration";
  static const String addPost = "/add-post";
  static const String addCaption = "/add-caption";
}