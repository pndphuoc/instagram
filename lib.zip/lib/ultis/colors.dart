import 'package:flutter/material.dart';

const mobileBackgroundColor = Color.fromARGB(0, 0, 0, 1);
const webBackgroundColor = Color.fromARGB(18, 18, 18, 1);
const mobileSearchColor = Color.fromARGB(38, 38, 38, 1);
const blueColor = Color.fromARGB(0, 149, 246, 1);
const primaryColor = Colors.white;
const secondaryColor = Color.fromARGB(255, 45, 45, 47);
const onBackground = Colors.white;
const postCardBackgroundColor = Color.fromARGB(255, 45, 45, 47);