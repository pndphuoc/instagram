import 'package:flutter/material.dart';
import 'package:instagram/provider/home_screen_provider.dart';
import 'package:instagram/route/route_name.dart';
import 'package:instagram/ultis/colors.dart';
import 'package:provider/provider.dart';

import '../view_model/asset_view_model.dart';

class MobileScreenLayout extends StatefulWidget {
  const MobileScreenLayout({Key? key}) : super(key: key);

  @override
  State<MobileScreenLayout> createState() => _MobileScreenLayoutState();
}

class _MobileScreenLayoutState extends State<MobileScreenLayout> {


  @override
  Widget build(BuildContext context) {
    return Consumer<HomeScreenProvider>(
      builder: (context, value, child) {
        return Scaffold(
          resizeToAvoidBottomInset: false,
          body: IndexedStack(
            index: value.currentIndex,
            children: value.screens,
          ),
          bottomNavigationBar: BottomNavigationBar(
              currentIndex: value.currentIndex,
              type: BottomNavigationBarType.fixed,
              showSelectedLabels: false,
              showUnselectedLabels: false,
              iconSize: 28,
              elevation: 0,
              backgroundColor: mobileBackgroundColor,
              onTap: (index) {
                if (index == 2) {
                  Navigator.pushNamed(context, RouteName.addPost).then((
                      value) =>
                      Provider.of<AssetViewModel>(context, listen: false)
                          .resetAssetViewModel());
                } else {
                  value.currentIndex = index;
                }
              },
              items: const [
                BottomNavigationBarItem(
                    icon: Icon(Icons.home_outlined, color: onBackground,),
                    activeIcon: Icon(Icons.home, color: onBackground),
                    label: 'home',
                    backgroundColor: mobileBackgroundColor
                ),
                BottomNavigationBarItem(
                    icon: Icon(Icons.search_outlined, color: onBackground,),
                    activeIcon: Icon(Icons.search, color: onBackground,),
                    label: 'search',
                    backgroundColor: mobileBackgroundColor
                ),
                BottomNavigationBarItem(
                    icon: Icon(Icons.add_circle_outline, color: onBackground),
                    label: 'add post',
                    backgroundColor: mobileBackgroundColor
                ),
                BottomNavigationBarItem(
                    icon: Icon(
                        Icons.favorite_border_outlined, color: onBackground),
                    activeIcon: Icon(Icons.favorite, color: onBackground),
                    label: 'notifications',
                    backgroundColor: mobileBackgroundColor
                ),
                BottomNavigationBarItem(
                    icon: Icon(Icons.person_outline, color: onBackground),
                    activeIcon: Icon(Icons.person, color: onBackground),
                    label: 'home',
                    backgroundColor: mobileBackgroundColor
                ),
              ]
          ),
        );
      },);
  }
}
